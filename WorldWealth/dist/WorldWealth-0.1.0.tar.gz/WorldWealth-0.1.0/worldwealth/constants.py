# TYPES OF GENES

# A person with this active gene will study after legal age
STUDY = 'STUDY'
# A person with this active gene will have children
BABY = 'BABY'
# A person with this active gene will die prematurely
P_DEATH = 'P_DEATH'
# A person with this active gene will invest some of ther money when begin to work
INVEST = 'INVEST'

# This gene define the percentage of money that a person will spend in other needs than the basic
S_MONEY = 'S_MONEY'
